$(function(){
	// 弹幕开启关闭开始
var zdShow = {
	init:function(){

		this.start()
		this.play()
		this.add()
	},
	start:function(){   ///打开页面默认弹幕
		this.wrap = document.getElementById('zdWrap');
		this.aLi = this.wrap.getElementsByTagName('li')
		var num = 40 //生成多少条
		var arr = ["111","22222","wsfsdfsdfsdfsd","asdas","qasdasdasdadasda","asdasdassdasdsa","asdassssssdasdasdsa",
				"111","22222","w发的sd","asdas","qasdasda的所得税苏定方sdadasda","asdasdassdasdsa","asdassssssdasdasdsa",
				"111","22222","wsfsd是是是是fsdfsdfsd","asdas","qasdasdasdada盛大盛大盛大盛大sda","asdasdassdasdsa","asdassssssdasdasdsa",
				"111","22222","wsfsd","asdas","qasdasdasdadasda","asdasdassdasdsa","asdassssssdasdasdsa",
				"111","22222","wsfsdfsdfsdfsd","asdas","qasdasdasda苏定方苏定方苏定方dasda","asdasdassdasdsa","asdassssssdasdasdsa",
				"111","22222","wsfsdfd","asdas","qasdasdasda","盛大发斯蒂芬苏定方苏定方","asdassssssdasdasdsa",
				"111","22222","wsfsdfd","asdas","qasdasdasda","盛大发斯蒂芬苏定方苏定方","asdassssssdasdasdsa",
				"111","22222","wsfsdfd","asdas","qasdasdasda","盛大发斯蒂芬苏定方苏定方","asdassssssdasdasdsa",
				]////模拟内容
		for(var i=0;i<num;i++){

			this.aLi[parseInt(i/(num/8))].innerHTML += "<div class='float float3'>"+
					//"<span class='left'></span>"+
					"<div class='f-cont'>"+
					"<img src='img/close.png' class='f-img'>"+ ///字体前方图像，可判断增加
						"<p class='text'>"+arr[i]+"</p>"+
						"<i class='num1'>0</i>"+
						"<span class='xin'></span>"+
					"</div>"+
					//"<span class='right'></span>"+
					"</div>"
		}////生成内容
		for(var i=0;i<this.aLi.length;i++){
			this.move(this.aLi[i],3,'left',-100000)			
			
		}
	
	},
	getByClass:function(sClass,parent){
		var aEles = (parent||document).getElementsByTagName('*');
		var arr = [];
		
		for(var i=0; i<aEles.length; i++){
			
			var aClass = aEles[i].className.split(' ');
		
			for(var j=0; j<aClass.length; j++){
				
				if( aClass[j] == sClass ){
				
					arr.push( aEles[i] );	
					break;
					
				}	
				
			}
			
		}
		
		return arr;

	},
	getStyle:function(obj, attr){

		 return obj.currentStyle?obj.currentStyle[attr]:getComputedStyle(obj, 0)[attr]; 

	},
	move:function(obj , num , attr , target , endFn){  ///移动

			num = parseInt(this.getStyle(obj, attr) ) < target ? num : -num;
			
			clearInterval( obj.timer );

			function fn(){
				obj.timer = setInterval(function() {
				var speed = parseInt( zdShow.getStyle(obj, attr) ) + num;
				
				if ( speed < target && num < 0 || speed > target && num > 0 ) {
					speed = target;
				}

				obj.style[attr] = speed + 'px';
				
				if ( speed == target ) {
					clearInterval( obj.timer );
					endFn && endFn();
				}
								
				}, 20);

			}

			fn()
			
			obj.onmouseover = function(){
				clearInterval( obj.timer )
			}
			obj.onmouseout = function(){
				fn()
			}

		


	},
	play:function(){   
		var oBtn =zdShow.getByClass('zdbtn',document)[0]	
		var _this = this 
		var num = 30
		var onOff = true
		oBtn.onclick = function(){  ///点击调用，，生成内容
			if (!onOff){
				alert('请30秒后再次尝试')
				return;
			}
			clearInterval(timer)
			function fn1(){
				var timer = setInterval(function(){
				num--;	
				if(num==0){
					onOff = true;
					clearInterval(timer)
					num=30
					
				}
				},1000)
			}
			fn1()

			
				_this.creatCon()
				_this.move(_this.oBox,3,'left','-2000')
				onOff = false	
			
		}

	},
	creatCon:function(){
		
		this.wrap = document.getElementById('zdWrap');
		this.oBox = document.createElement('div');
		this.input = document.getElementById('input');
		this.aLi = this.wrap.getElementsByTagName('li')	
		this.oBox.className = "float";
		//////生成内容
		this.oBox.innerHTML = "<div class='f-cont'><p class='text'></p><i class='num1' id='num1'>0</i><span class='xin'></span></div>"
		var iNum = Math.round( Math.random()*4)
		this.aLi[iNum].appendChild(this.oBox)	
		this.text = this.getByClass('text',this.oBox)[0]
		this.oP = this.getByClass('num1',this.oBox)[0]
		
		this.text.innerHTML = this.input.value
		//this.text.style.color = 'blue'
		//this.oP.style.color = 'blue'
		
		this.add()

		

	},
	add:function(){///增加点赞数

		this.oFloat = this.getByClass('float',this.wrap)
		this.text = this.getByClass('text',this.oBox)[0]
		var _this = this
				
		for(var i=0;i<this.oFloat.length;i++){
			this.oFloat[i].onOff = true
			this.oFloat[i].onclick = function(){

				var addNum = zdShow.getByClass('num1',this)[0]
				var otext = zdShow.getByClass('text',this)[0]
				var xin = zdShow.getByClass('xin',this)[0]
				var ownNum = addNum.innerHTML
				if(this.onOff){
					ownNum++
					this.onOff = false 
				}
				
				addNum.innerHTML = ownNum
				xin.style.background = "url(img/xin.png) no-repeat 0 -54px"
				otext.style.color = '#ffd102'
				addNum.style.color = '#ffd102'
				
			}

		}
	}


}
zdShow.init()

	$('.close').toggle(function(){
		$(this).attr('src','img/open.png');
		$('.flag_text').css('background','url(img/open_text.png)');
		$('.float').css('display','none');
	},function(){
		$(this).attr('src','img/close.png');
		$('.flag_text').css('background','url(img/close_text.png)');
		$('.float').css('display','block')
	})
	$('.flag_text').toggle(function(){
		$('.close').attr('src','img/open.png');
		$('.flag_text').css('background','url(img/open_text.png)');
		$('.float').css('display','none');
	},function(){
		$('.close').attr('src','img/close.png');
		$('.flag_text').css('background','url(img/close_text.png)');
		$('.float').css('display','block');
	})
	// 琅琊点赞榜开始
	var langya = $('.langya').get(0);
	var pull_down = $('.pull_down').get(0);
	var timer = null; 
	pull_down.onmouseover = langya.onmouseover = function(){
			clearTimeout(timer);
			pull_down.style.display = 'block'
		}
		pull_down.onmouseout = langya.onmouseout = function(){
			timer = setTimeout(function(){
				pull_down.style.display = 'none';
			},600)
		}
	var accounts = ['zttgyhj0611','874098230@qq.com','123@126.com','126548922335','xiaolingdang@163.com','zttgyhj0616','zttgyhj0617','zttgyhj0618','zttgyhj0617','zttgyhj0618'];
	var result = '';
	var num = ['1','2','3','4','5','6','7','8','9','10'];
	var max_num = ['1258','1358','2589','1234','2569','245','1566','2364','1489','1547'];
	for(var i = 0;i<accounts.length;i++){
		var span=accounts[i];
		var max = max_num[i];
		var s = num[i];
		str=span.substring(0,3)+"*****"+span.substring(span.length-4,span.length);
		result+="<li><em class='gold num'>"+s+"</em> "+"<span class='gold info'>" +str+"</span><i></i><em class='max_num'>"+max+"</em></li>" ;
	}
	$('.pull_down ul').html(result);
	// 点赞开始
	




})
	